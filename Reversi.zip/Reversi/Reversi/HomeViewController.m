//
//  HomeViewController.m
//  Reversi
//
//  Created by zhaimengyang on 6/18/16.
//  Copyright © 2016 zhaimengyang. All rights reserved.
//

#import "HomeViewController.h"
#import "IntroductionView.h"
#include "GameViewController.h"
#include "UIView+Frame.h"

@interface HomeViewController ()

@property (weak, nonatomic) IBOutlet UIScrollView *gameSizeScrollView;
@property (assign, nonatomic) BOOL sizeButtonAdded;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.gameSizeScrollView.hidden = YES;
    self.gameSizeScrollView.alpha = 0.0;
    
    self.sizeButtonAdded = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (self.gameSizeScrollView.hidden == NO) {
        [UIView animateWithDuration:0.5 animations:^{
            self.gameSizeScrollView.alpha = 0.0;
        } completion:^(BOOL finished) {
            self.gameSizeScrollView.hidden = YES;
        }];
    }
}

#pragma mark - Action Methods

- (IBAction)showGameIntroduction:(UIButton *)sender {
    CGSize selfSize = self.view.bounds.size;
    IntroductionView *introductionView = [[IntroductionView alloc]initWithFrame:CGRectMake(0, 0, selfSize.width - 70, 200)];
    introductionView.toPoint = CGPointMake(sender.center.x, sender.center.y - 150);
    [introductionView showFromView:sender];
}

- (IBAction)startGame:(UIButton *)sender {
    if (self.gameSizeScrollView.hidden == YES) {
        self.gameSizeScrollView.hidden = NO;
        [UIView animateWithDuration:0.5 animations:^{
            self.gameSizeScrollView.alpha = 1.0;
        } completion:^(BOOL finished) {
            if (self.sizeButtonAdded == NO) {
                [self addSizeButton];
            }
        }];
    }
}

- (void)addSizeButton {
    CGFloat margin = 10;
    CGFloat w = 30;
    UIView *view = [[UIView alloc]init];
    view.backgroundColor = [UIColor lightGrayColor];
    for (NSInteger i = 4, j = 0; i <= 40; i += 2, j++) {
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(j * (w + margin), 0, w, self.gameSizeScrollView.height)];
        button.tag = i;
        [button setTitle:[NSString stringWithFormat:@"%ld", (long)i] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(selectSize:) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:button];
        if (i == 40) {
            view.width = button.x + button.width;
            view.height = self.gameSizeScrollView.height;
        }
    }
    
    [self.gameSizeScrollView addSubview:view];
    self.gameSizeScrollView.contentSize = view.size;
}

- (void)selectSize:(UIButton *)button {
    GameViewController *gameVC = [[GameViewController alloc]initWithBoardSize:button.tag];
    [self presentViewController:gameVC animated:YES completion:^{
        self.gameSizeScrollView.hidden = YES;
        self.gameSizeScrollView.alpha = 0.0;
    }];
}


//#pragma mark - Navigation
//
//- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
//    // Get the new view controller using [segue destinationViewController].
//    // Pass the selected object to the new view controller.
//}


@end
