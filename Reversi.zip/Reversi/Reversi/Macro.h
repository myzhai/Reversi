//
//  Macro.h
//  Reversi
//
//  Created by zhaimengyang on 6/18/16.
//  Copyright © 2016 zhaimengyang. All rights reserved.
//

#ifndef Macro_h
#define Macro_h

#ifndef comp_c
#define comp_c 'c'
#endif

#ifndef player_c
#define player_c 'p'
#endif

#ifndef none_c
#define none_c ' '
#endif

#endif /* Macro_h */
