//
//  CounterCoordinate.h
//  Reversi
//
//  Created by zhaimengyang on 6/18/16.
//  Copyright © 2016 zhaimengyang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CounterCoordinate : NSObject

@property (assign, nonatomic) NSInteger row;
@property (assign, nonatomic) NSInteger col;

- (instancetype)initWithRow:(NSInteger)row col:(NSInteger)col;
+ (instancetype)counterCoordinateWithRow:(NSInteger)row col:(NSInteger)col;

@end
