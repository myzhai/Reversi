//
//  GameView.m
//  Reversi
//
//  Created by zhaimengyang on 6/18/16.
//  Copyright © 2016 zhaimengyang. All rights reserved.
//

#import "GameView.h"
#import "UIView+Frame.h"
#import "CounterButton.h"
#import "GameHandler.h"

@interface GameView ()

@property (strong, nonatomic) GameHandler *gameHandler;

@property (assign, nonatomic) BOOL canPlaceCounter;
@property (assign, nonatomic) BOOL initialized;

@property (strong, nonatomic) CounterButton *passButton;

@end

static const CGFloat margin = 5;

@implementation GameView
{
    char board[40][40];
}

- (instancetype)initWithBoardSize:(NSInteger)boardSize {
    if (self = [super init]) {
        self.boardSize = boardSize;
        [self addCounters:boardSize];
        [self addPassButton];
    }
    
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor blackColor];
        self.boardSize = 6;
        self.initialized = NO;
        self.nextPlayer = GameViewPlayerPlayer;
    }
    
    return self;
}

- (void)addCounters:(NSInteger)count {
    for (NSInteger row = 0; row < count; row++) {
        for (NSInteger col = 0; col < count; col++) {
            CounterButton *button = [[CounterButton alloc]init];
            button.row = row;
            button.col = col;
            button.counterState = CounterButtonStateNone;
            button.backgroundColor = [UIColor brownColor];
            [self addSubview:button];
            
            [button addTarget:self action:@selector(counterButtonDidClick:) forControlEvents:UIControlEventTouchUpInside];
        }
    }
}

- (void)addPassButton {
    CounterButton *pass = [[CounterButton alloc]init];
    pass.row = -1;
    pass.col = -1;
    pass.counterState = CounterButtonStateNone;
    [pass setTitle:@"无路可走 Pass" forState:UIControlStateNormal];
    [pass setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    pass.titleLabel.font = [UIFont systemFontOfSize:18];
    [pass sizeToFit];
    [self addSubview:pass];
    pass.hidden = YES;
    [pass addTarget:self action:@selector(passButtonDidClick:) forControlEvents:UIControlEventTouchUpInside];
    self.passButton = pass;
}

- (CGFloat)extraHeight {
    CounterButton *pass = [[CounterButton alloc]init];
    [pass setTitle:@"Pass" forState:UIControlStateNormal];
    [pass sizeToFit];
    return pass.size.height;
}

- (void)counterButtonDidClick:(CounterButton *)button {
    if (self.canPlaceCounter) {
        [self.gameHandler placeCounterAtCounterCoordinate:[CounterCoordinate counterCoordinateWithRow:button.row col:button.col]];
    }
}

- (void)passButtonDidClick:(CounterButton *)button {
    self.nextPlayer = !self.nextPlayer;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    NSInteger count = self.boardSize;
    CGFloat w = (CGFloat)(self.frame.size.width - (count - 1) * margin) / count;
    for (CounterButton *button in self.subviews) {
        if (button.row == -1 && button.col == -1) {
            button.centerX = self.centerX;
            button.y = self.bounds.size.width + margin;
        } else {
            button.x = button.col * (w + margin);
            button.y = button.row * (w + margin);
            button.width = w;
            button.height = w;
        }
    }
}

- (void)willMoveToSuperview:(UIView *)newSuperview {
    self.gameHandler = [[GameHandler alloc] initWithGameBoard:board size:self.boardSize completionHandler:^(NSDictionary *info) {
        NSLog(@"info --> %@", info);
        if ([info[kGameOver] boolValue]) {
            [self gameOver];
        }
        
        if ([info[kChanges] boolValue]) {
            [self refresh];
            self.initialized = YES;
            
            if (info[kComputerCoordinate]) {
                CounterButton *target;
                CounterCoordinate *coordinate = (CounterCoordinate *)info[kComputerCoordinate];
                for (CounterButton *button in self.subviews) {
                    if (button.row == coordinate.row && button.col == coordinate.col) {
                        target = button;
                        break;
                    }
                }
                
                [UIView animateWithDuration:0.3 animations:^{
                    target.transform = CGAffineTransformMakeScale(1.2, 1.2);
                } completion:^(BOOL finished) {
                    [UIView animateWithDuration:0.2 animations:^{
                        target.transform = CGAffineTransformMakeScale(0.8, 0.8);
                    } completion:^(BOOL finished) {
                        [UIView animateWithDuration:0.1 animations:^{
                            target.transform = CGAffineTransformIdentity;
                        }];
                    }];
                }];
            }
        }
        
        if (info[kInvalidMove]) {
            CounterButton *target;
            CounterCoordinate *coordinate = (CounterCoordinate *)info[kInvalidMove];
            for (CounterButton *button in self.subviews) {
                if (button.row == coordinate.row && button.col == coordinate.col) {
                    target = button;
                    break;
                }
            }
            [target setImage:[UIImage imageNamed:@"invalid"] forState:UIControlStateNormal];
            [UIView animateWithDuration:0.3 animations:^{
                target.transform = CGAffineTransformMakeScale(1.2, 1.2);
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:0.2 animations:^{
                    target.transform = CGAffineTransformMakeScale(0.8, 0.8);
                } completion:^(BOOL finished) {
                    [UIView animateWithDuration:0.1 animations:^{
                        target.transform = CGAffineTransformIdentity;
                        [target setImage:nil forState:UIControlStateNormal];
                    }];
                }];
            }];
        }
        
        if (info[kPass]) {
            NSString *pass = info[kPass];
            if ([pass isEqualToString:kPassComputer]) {
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Pass" message:@"xxoo" preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *action = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                    self.nextPlayer = !self.nextPlayer;
                }];
                [alert addAction:action];
                [self.gameVC presentViewController:alert animated:YES completion:nil];
            }
            if ([pass isEqualToString:kPassPlayer]) {
                self.passButton.hidden = NO;
                self.canPlaceCounter = NO;
            }
        }
    }];
}

- (void)gameOver {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"游戏结束" message:@"xxoo" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleCancel handler:nil];
    [alert addAction:action];
    [self.gameVC presentViewController:alert animated:YES completion:nil];
}

- (void)refresh {
    for (CounterButton *button in self.subviews) {
        if (button.row == -1 && button.col == -1) {
            continue;
        }
        char state_c = board[button.row][button.col];
        switch (state_c) {
            case none_c:
                [button setImage:nil forState:UIControlStateNormal];
                button.counterState = CounterButtonStateNone;
                break;
            case comp_c:
                [button setImage:[UIImage imageNamed:@"happy"] forState:UIControlStateNormal];
                button.counterState = CounterButtonStateComputer;
                break;
            case player_c:
                [button setImage:[UIImage imageNamed:@"cool"] forState:UIControlStateNormal];
                button.counterState = CounterButtonStatePlayer;
                break;
            default:
                break;
        }
    }
    
    [self.gameVC setScores:self.gameHandler.scores];
    
    if (self.initialized) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.nextPlayer = !self.nextPlayer;
        });
    }
}

- (void)setNextPlayer:(GameViewPlayer)nextPlayer {
    _nextPlayer = nextPlayer;
    
    switch (nextPlayer) {
        case GameViewPlayerPlayer:
            self.canPlaceCounter = YES;
            break;
        case GameViewPlayerComputer:
            self.canPlaceCounter = NO;
            [self.gameHandler computerMove];
            break;
        default:
            break;
    }
}

@end
