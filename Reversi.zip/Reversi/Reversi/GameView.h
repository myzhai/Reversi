//
//  GameView.h
//  Reversi
//
//  Created by zhaimengyang on 6/18/16.
//  Copyright © 2016 zhaimengyang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GameViewController.h"

typedef NS_ENUM(NSUInteger, GameViewPlayer) {
    GameViewPlayerPlayer,
    GameViewPlayerComputer,
};

@interface GameView : UIView

- (instancetype)initWithBoardSize:(NSInteger)boardSize;
@property (assign, nonatomic) NSInteger boardSize;

@property (assign, nonatomic) GameViewPlayer nextPlayer;

@property (weak, nonatomic) GameViewController *gameVC;

- (CGFloat)extraHeight;

@end
