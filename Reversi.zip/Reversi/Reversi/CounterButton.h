//
//  CounterButton.h
//  Reversi
//
//  Created by zhaimengyang on 6/18/16.
//  Copyright © 2016 zhaimengyang. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, CounterButtonState) {
    CounterButtonStateNone,
    CounterButtonStatePlayer,
    CounterButtonStateComputer,
};

@interface CounterButton : UIButton

@property (assign, nonatomic) NSInteger row;
@property (assign, nonatomic) NSInteger col;
@property (assign, nonatomic) CounterButtonState counterState;

@end
