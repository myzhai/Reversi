//
//  GameHandler.m
//  Reversi
//
//  Created by zhaimengyang on 6/18/16.
//  Copyright © 2016 zhaimengyang. All rights reserved.
//

#import "GameHandler.h"

static const NSInteger MAX_SIZE = 40;

/*************************************************/
 
NSInteger initialize(char board[][MAX_SIZE], NSInteger size) {
    for (int row = 0; row < size; row++) {
        for (int col = 0; col < size; col++) {
            board[row][col] = ' ';
        }
    }
    
    NSInteger mid = size / 2;
    board[mid-1][mid-1] = board[mid][mid] = player_c;
    board[mid-1][mid] = board[mid][mid-1] = comp_c;
    
    return 4;
}

NSInteger valid_moves(char board[][MAX_SIZE], bool moves[][MAX_SIZE], NSInteger size, char player) {
    NSInteger rowdelta = 0;
    NSInteger coldelta = 0;
    NSInteger x = 0;
    NSInteger y = 0;
    NSInteger num_of_moves = 0;
    char opponent = (player == player_c) ? comp_c : player_c;
    
    for (NSInteger row = 0; row < size; row++) {
        for (NSInteger col = 0; col < size; col++) {
            moves[row][col] = false;
        }
    }
    
    for (NSInteger row = 0; row < size; row++) {
        for (NSInteger col = 0; col < size; col++) {
            if (board[row][col] != none_c)
                continue;
            
            for (rowdelta = -1; rowdelta <= 1; rowdelta++) {
                for (coldelta = -1; coldelta <= 1; coldelta++) {
                    if (row + rowdelta < 0 || row + rowdelta >= size
                        || col + coldelta < 0 || col + coldelta >= size
                        || (rowdelta == 0 && coldelta == 0))
                        continue;
                    
                    if (board[x = row + rowdelta][y = col + coldelta] == opponent) {
                        while (true) {
                            x += rowdelta;
                            y += coldelta;
                            
                            if (x < 0 || x >= size || y < 0 || y >= size)
                                break;
                            if (board[x][y] == none_c)
                                break;
                            if (board[x][y] == player) {
                                moves[row][col] = true;
                                num_of_moves++;
                                break;
                            }
                            //**********
                        }
                    }
                    //if (board[x = row + rowdelta][y = col + coldelta] == opponent)
                }
            }
            //for (rowdelta = -1; rowdelta <= 1; rowdelta++)
        }
    }
    
    return num_of_moves;
}

void make_move(char board[][MAX_SIZE], NSInteger size, NSInteger row, NSInteger col, char player) {
    NSInteger rowdelta = 0;
    NSInteger coldelta = 0;
    NSInteger x = 0;
    NSInteger y = 0;
    char opponent = (player == player_c) ? comp_c : player_c;
    
    board[row][col] = player;
    
    for (rowdelta = -1; rowdelta <= 1; rowdelta++) {
        for (coldelta = -1; coldelta <= 1; coldelta++) {
            if (row + rowdelta < 0 || row + rowdelta >= size
                || col + coldelta < 0 || col + coldelta >= size
                || (rowdelta == 0 && coldelta == 0))
                continue;
            
            if (board[x = row + rowdelta][y = col + coldelta] == opponent) {
                while (true) {
                    x += rowdelta;
                    y += coldelta;
                    
                    if (x < 0 || x >= size || y < 0 || y >= size)
                        break;
                    if (board[x][y] == none_c)
                        break;
                    if (board[x][y] == player) {
                        while (board[x -= rowdelta][y -= coldelta] == opponent) {
                            board[x][y] = player;
                        }
                        break;
                    }
                    //**********
                }
            }
            //if (board[x = row + rowdelta][y = col + coldelta] == opponent)
        }
    }
    //for (rowdelta = -1; rowdelta <= 1; rowdelta++)
}

NSInteger get_score(char board[][MAX_SIZE], NSInteger size, NSInteger *comp_score, NSInteger *user_score, char player) {
    NSInteger _comp_score = 0;
    NSInteger _user_score = 0;
    
    for (NSInteger row = 0; row < size; row++) {
        for (NSInteger col = 0; col < size; col++) {
            _comp_score += board[row][col] == comp_c;
            _user_score += board[row][col] == player_c;
        }
    }
    
    if (comp_score)
        *comp_score = _comp_score;
    if (user_score)
        *user_score = _user_score;
    
    return player == player_c ? _user_score - _comp_score : (player == comp_c ? _comp_score - _user_score : -101);
}

NSInteger best_move(char board[][MAX_SIZE], bool moves[][MAX_SIZE], NSInteger size, char player) {
    char new_board[MAX_SIZE][MAX_SIZE] = {0};
    NSInteger score = -size * size;
    NSInteger new_score = 0;
    
    for (NSInteger row = 0; row < size; row++) {
        for (NSInteger col = 0; col < size; col++) {
            if (!moves[row][col])
                continue;
            
            memcpy(new_board, board, sizeof(new_board));
            make_move(new_board, size, row, col, player);
            new_score = get_score(new_board, size, NULL, NULL, player);
            
            if (new_score > score)
                score = new_score;
        }
    }
    
    return score;
}


CounterCoordinate * computer_move(char board[][MAX_SIZE], bool moves[][MAX_SIZE], NSInteger size, char player) {
    NSInteger best_row = 0;
    NSInteger best_col = 0;
    NSInteger score = size * size;
    NSInteger new_score = 0;
    char temp_board[MAX_SIZE][MAX_SIZE];
    bool temp_moves[MAX_SIZE][MAX_SIZE];
    char opponent = player == player_c ? comp_c : player_c;
    
    for (NSInteger row = 0; row < size; row++) {
        for (NSInteger col = 0; col < size; col++) {
            if (!moves[row][col])
                continue;
            
            memcpy(temp_board, board, sizeof(temp_board));
            make_move(temp_board, size, row, col, player);
            valid_moves(temp_board, temp_moves, size, opponent);
            new_score = best_move(temp_board, temp_moves, size, opponent);
            
            if (new_score < score) {
                score = new_score;
                best_row = row;
                best_col = col;
            }
        }
    }
    
    make_move(board, size, best_row, best_col, player);
    
    return [CounterCoordinate counterCoordinateWithRow:best_row col:best_col];
}
 
 /*************************************************/


@interface GameHandler ()

@property (assign, nonatomic) NSInteger invalidMoves;
@property (assign, nonatomic) NSInteger numOfMoves;
@property (assign, nonatomic) NSInteger size;

@end

NSString * const kChanges = @"kChanges";
NSString * const kGameOver = @"kGameOver";
NSString * const kComputerCoordinate = @"kComputerCoordinate";
NSString * const kInvalidMove = @"kInvalidMove";
NSString * const kPass = @"kPass";
NSString * const kPassComputer = @"kPassComputer";
NSString * const kPassPlayer = @"kPassPlayer";

@implementation GameHandler
{
    bool _moves[MAX_SIZE][MAX_SIZE];
    char (*_pboard)[MAX_SIZE];
    CompletionHandler _completionHandler;
}

- (instancetype)initWithGameBoard:(char [40][40])board size:(NSInteger)size completionHandler:(CompletionHandler)completionHandler {
    if (self = [super init]) {
        _numOfMoves = initialize(board, size);
        _pboard = board;
        _size = size;
        _invalidMoves = 0;
        if (completionHandler) {
            _completionHandler = [completionHandler copy];
            NSMutableDictionary *info = [NSMutableDictionary dictionary];
            info[kChanges] = [NSNumber numberWithBool:YES];
            completionHandler(info);
        }
    }
    
    return self;
}

- (NSArray<NSNumber *> *)scores {
    NSInteger comp_score;
    NSInteger user_score;
    get_score(_pboard, self.size, &comp_score, &user_score, 0);
    return [NSArray arrayWithObjects:@(comp_score), @(user_score), nil];
}

- (void)computerMove {
    if (valid_moves(_pboard, _moves, self.size, comp_c)) {
        CounterCoordinate *coordinate = computer_move(_pboard, _moves, self.size, comp_c);
        if (_completionHandler) {
            NSMutableDictionary *info = [NSMutableDictionary dictionary];
            info[kChanges] = [NSNumber numberWithBool:YES];
            info[kComputerCoordinate] = coordinate;
            _completionHandler(info);
        }
        self.invalidMoves = 0;
        self.numOfMoves++;
    } else {
        if (++self.invalidMoves < 2) {
            NSLog(@"Computer has to pass");
            [self passBy:kPassComputer];
        }
    }
}

- (void)placeCounterAtCounterCoordinate:(CounterCoordinate *)coordinate {
    if (valid_moves(_pboard, _moves, self.size, player_c)) {
        NSInteger row = coordinate.row;
        NSInteger col = coordinate.col;
        if (row >= 0 && col >= 0 && row < self.size && col < self.size && _moves[row][col]) {
            make_move(_pboard, self.size, row, col, player_c);
            if (_completionHandler) {
                NSMutableDictionary *info = [NSMutableDictionary dictionary];
                info[kChanges] = [NSNumber numberWithBool:YES];
                _completionHandler(info);
            }
            self.invalidMoves = 0;
            self.numOfMoves++;
        } else {
            if (_completionHandler) {
                NSMutableDictionary *info = [NSMutableDictionary dictionary];
                info[kInvalidMove] = coordinate;
                _completionHandler(info);
            }
        }
    } else {
        if (++self.invalidMoves < 2) {
            NSLog(@"You have to pass");
            [self passBy:kPassPlayer];
        }
    }
}

- (void)gameOver {
    NSMutableDictionary *info = [NSMutableDictionary dictionary];
    info[kGameOver] = [NSNumber numberWithBool:YES];
    [self executeCompletionHandler:info];
}

- (void)passBy:(NSString *)pass {
    NSMutableDictionary *info = [NSMutableDictionary dictionary];
    info[kPass] = pass;
    [self executeCompletionHandler:info];
}

- (void)executeCompletionHandler:(NSDictionary *)info {
    if (_completionHandler) {
        _completionHandler(info);
    }
}

- (void)setNumOfMoves:(NSInteger)numOfMoves {
    _numOfMoves = numOfMoves;
    
    if (numOfMoves >= self.size * self.size) {
        [self gameOver];
    }
}

- (void)setInvalidMoves:(NSInteger)invalidMoves {
    _invalidMoves = invalidMoves;
    
    if (invalidMoves >= 2) {
        [self gameOver];
    }
}

@end
