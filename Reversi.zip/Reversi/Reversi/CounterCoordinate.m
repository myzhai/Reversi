//
//  CounterCoordinate.m
//  Reversi
//
//  Created by zhaimengyang on 6/18/16.
//  Copyright © 2016 zhaimengyang. All rights reserved.
//

#import "CounterCoordinate.h"

@implementation CounterCoordinate

+ (instancetype)counterCoordinateWithRow:(NSInteger)row col:(NSInteger)col {
    CounterCoordinate *coordinate = [[self alloc]initWithRow:row col:col];
    return coordinate;
}

- (instancetype)initWithRow:(NSInteger)row col:(NSInteger)col {
    if (self = [super init]) {
        self.row = row;
        self.col = col;
    }
    
    return self;
}

@end
