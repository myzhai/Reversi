//
//  GameViewController.m
//  Reversi
//
//  Created by zhaimengyang on 6/18/16.
//  Copyright © 2016 zhaimengyang. All rights reserved.
//

#import "GameViewController.h"
#import "GameView.h"
#import "UIView+Frame.h"

@interface GameViewController ()

@property (strong, nonatomic) GameView *gameView;

@property (strong, nonatomic) UILabel *scoreLabel;

@property (strong, nonatomic) UIButton *backButton;


@end

@implementation GameViewController

- (instancetype)initWithBoardSize:(NSInteger)boardSize {
    if (self = [super init]) {
        _boardSize = 8;
        if (boardSize >= 4 && boardSize <= 40 && boardSize % 2 == 0) {
            _boardSize = boardSize;
        }
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithRed:249/255.0 green:217/255.0 blue:91/255.0 alpha:1.0];
    self.gameView = [[GameView alloc]initWithBoardSize:_boardSize];
    self.gameView.gameVC = self;
    
    self.backButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 20, 0, 0)];
    [self.backButton setTitle:@"不玩了" forState:UIControlStateNormal];
    [self.backButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [self.backButton sizeToFit];
    [self.view addSubview:self.backButton];
    [self.backButton addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    
    self.scoreLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.backButton.width + 150, 20, 0, 0)];
    [self.view addSubview:self.scoreLabel];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    CGFloat w = MIN(self.view.bounds.size.width, self.view.bounds.size.height);
    self.gameView.frame = CGRectMake(0, 64, w, w + self.gameView.extraHeight);
    [self.view addSubview:self.gameView];
}

- (void)back {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)setScores:(NSArray<NSNumber *> *)scores {
    NSString *str = [NSString stringWithFormat:@"iPhone: %ld   you: %ld", (long)[scores[0] integerValue], (long)[scores[1] integerValue]];
    self.scoreLabel.text = str;
    [self.scoreLabel sizeToFit];
    self.scoreLabel.centerY = self.backButton.centerY;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
