//
//  GameViewController.h
//  Reversi
//
//  Created by zhaimengyang on 6/18/16.
//  Copyright © 2016 zhaimengyang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GameViewController : UIViewController

@property (readonly, nonatomic) NSInteger boardSize;
- (instancetype)initWithBoardSize:(NSInteger)boardSize;
- (void)setScores:(NSArray <NSNumber *>*)scores;

@end
