//
//  CounterButton.m
//  Reversi
//
//  Created by zhaimengyang on 6/18/16.
//  Copyright © 2016 zhaimengyang. All rights reserved.
//

#import "CounterButton.h"

@implementation CounterButton

- (void)setHighlighted:(BOOL)highlighted {
    if (self.row == -1 && self.col == -1) {
        [super setHighlighted:highlighted];
    }
}

- (void)sendAction:(SEL)action to:(id)target forEvent:(UIEvent *)event {
    if (self.counterState == CounterButtonStateNone) {
        [super sendAction:action to:target forEvent:event];
    }
}

@end
