//
//  IntroductionView.h
//  Reversi
//
//  Created by zhaimengyang on 6/18/16.
//  Copyright © 2016 zhaimengyang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IntroductionView : UINavigationBar

@property (assign, nonatomic) BOOL allowsUserToContinue;
@property (assign, nonatomic) CGPoint toPoint;

- (void)showFromView:(UIView *)view;
- (void)dismiss;

@end
