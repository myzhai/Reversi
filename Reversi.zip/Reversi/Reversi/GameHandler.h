//
//  GameHandler.h
//  Reversi
//
//  Created by zhaimengyang on 6/18/16.
//  Copyright © 2016 zhaimengyang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "CounterCoordinate.h"
#import "Macro.h"

UIKIT_EXTERN NSString * const kChanges;
UIKIT_EXTERN NSString * const kGameOver;
UIKIT_EXTERN NSString * const kComputerCoordinate;
UIKIT_EXTERN NSString * const kInvalidMove;
UIKIT_EXTERN NSString * const kPass;
UIKIT_EXTERN NSString * const kPassComputer;
UIKIT_EXTERN NSString * const kPassPlayer;

typedef void(^CompletionHandler)(NSDictionary *info);

@interface GameHandler : NSObject

- (instancetype)initWithGameBoard:(char [40][40])board size:(NSInteger)size completionHandler:(CompletionHandler)completionHandler;

- (void)computerMove;
- (void)placeCounterAtCounterCoordinate:(CounterCoordinate *)coordinate ;

- (NSArray <NSNumber *>*)scores;

@end
